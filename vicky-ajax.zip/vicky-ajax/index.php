<?php
    session_start();
    if(isset($_SESSION['user'])){
        header('location:home.php');
    }
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css"/>
</head>
<body>

<div class="container">
    <div class="row">
        <div id="myalert" style="display:none;">
            <div class="alert alert-info">
                <center><span id="alerttext"></span></center>
            </div>
        </div>
    </div>
     
    <div class="row loginreg" id="loginform">
        <p><h1><i class="fa fa-lock" aria-hidden="true"></i> Login</h1></p>
        <form role="form" id="logform">
            <div class="input-group mb-3">
                <span class="input-group-text"><i class="fas fa-user-tie"></i></span>
                <input class="form-control" placeholder="Username" name="username" id="username" type="text" autofocus>
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text"><i class="fa fa-key icon"></i></span>
                <input class="form-control" placeholder="Password" name="password" id="password" type="password">
            </div>
            <div class="checkbox">
                  <label><input type="checkbox" value=""/> Remember me</label>
            </div><br />
            <div>
                <button type="button" id="loginbutton" class="btn btn-lg btn-primary btn-block"><i class="fa fa-lock" aria-hidden="true"></i> <span id="logtext">Login</span></button>
            </div>
             
            <center><div style="border:1px solid black;height:1px;width:300px;margin-top:20px;"></div></center>
              
            <div class="footer">
                <p>Don't have an Account! <a href="#" id="signup">Sign Up Here</a></p>
                <p>Forgot <a href="#">Password?</a></p>
            </div>
        </form>
    </div>    
     
    <div class="row loginreg" id="signupform" style="display:none;">
        <p><h1><i class="fas fa-user-tie"></i> Sign Up</h1></p>
        <form role="form" id="signform">
            <div class="input-group mb-3">
                <span class="input-group-text"><i class="fas fa-user-tie"></i></span>
                <input class="form-control" placeholder="Username" name="susername" id="susername" type="text" autofocus>
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text"><i class="fa fa-key icon"></i></span>
                <input class="form-control" placeholder="Password" name="spassword" id="spassword" type="password">
            </div>
            <div>
                <button type="button" id="signupbutton" class="btn btn-lg btn-info btn-block"><i class="fa fa-lock" aria-hidden="true"></i> <span id="signtext">Sign Up</span></button>
            </div>
             
            <center><div style="border:1px solid black;height:1px;width:300px;margin-top:20px;"></div></center>
              
            <div class="footer">
                <p>have an Account! <a href="#" id="login">Login</a></p>
                <p>Forgot <a href="#">Password?</a></p>
            </div>
        </form>
    </div>
</div>
<script src="script.js"></script>
<style>
  .container{
        border:2px solid blue;
        text-align:center;
         
        height:500px;
        width:400px;
    }
    body{
        padding:70px;
    }
    .loginreg {
        height:90px;
        width:396px;
        background-color:paleturquoise;
    }
    .row p { 
        padding-top:10px;
    }
</style>  
</body>
</html>